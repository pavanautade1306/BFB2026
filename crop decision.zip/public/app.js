// CropSmart - Crop Decision Intelligence System

document.addEventListener('DOMContentLoaded', function() {
  // Check if user is logged in
  if (sessionStorage.getItem('isLoggedIn') !== 'true') {
    window.location.href = 'index.html';
    return;
  }
  
  const cropForm = document.getElementById('cropForm');
  const resultsSection = document.getElementById('resultsSection');
  const cropsGrid = document.getElementById('cropsGrid');
  
  // Crop database with ideal conditions
  const crops = [
    {
      name: 'Rice',
      icon: '🌾',
      idealSoil: ['clay', 'loamy'],
      idealRainfall: ['above_1000'],
      idealTemperature: ['20_30', '30_40'],
      idealWaterSource: ['irrigated'],
      idealRegion: ['south', 'east', 'north'],
      yieldPerAcre: '20-25 quintals',
      priceRange: '₹1,800 - ₹2,200/quintal',
      reasons: {
        soil: 'Thrives in water-retentive clay and loamy soils',
        rainfall: 'Requires high rainfall (>1000mm) for paddy cultivation',
        temperature: 'Optimal growth in warm humid conditions (20-40°C)',
        waterSource: 'Needs consistent irrigation for flooded paddies',
        region: 'Well-suited to the climatic conditions of this region'
      }
    },
    {
      name: 'Wheat',
      icon: '🌾',
      idealSoil: ['loamy', 'clay'],
      idealRainfall: ['500_1000'],
      idealTemperature: ['below_20', '20_30'],
      idealWaterSource: ['irrigated', 'rain_fed'],
      idealRegion: ['north', 'central'],
      yieldPerAcre: '15-20 quintals',
      priceRange: '₹2,000 - ₹2,400/quintal',
      reasons: {
        soil: 'Grows best in well-drained loamy and clay soils',
        rainfall: 'Moderate rainfall (500-1000mm) is ideal',
        temperature: 'Prefers cool to moderate temperatures for grain filling',
        waterSource: 'Adapts well to both irrigation and rain-fed conditions',
        region: 'Traditionally cultivated in the Indo-Gangetic plains'
      }
    },
    {
      name: 'Cotton',
      icon: '☁️',
      idealSoil: ['black_cotton', 'loamy'],
      idealRainfall: ['500_1000'],
      idealTemperature: ['20_30', '30_40'],
      idealWaterSource: ['irrigated'],
      idealRegion: ['central', 'west', 'south'],
      yieldPerAcre: '8-12 quintals',
      priceRange: '₹5,500 - ₹6,500/quintal',
      reasons: {
        soil: 'Black cotton soil retains moisture ideal for cotton',
        rainfall: 'Requires moderate rainfall with dry harvest period',
        temperature: 'Warm temperatures promote fiber development',
        waterSource: 'Consistent irrigation ensures quality fiber',
        region: 'Well-adapted to the cotton belt of India'
      }
    },
    {
      name: 'Sugarcane',
      icon: '🎋',
      idealSoil: ['loamy', 'clay'],
      idealRainfall: ['above_1000'],
      idealTemperature: ['20_30', '30_40'],
      idealWaterSource: ['irrigated'],
      idealRegion: ['north', 'south', 'west'],
      yieldPerAcre: '350-450 quintals',
      priceRange: '₹280 - ₹350/quintal',
      reasons: {
        soil: 'Deep loamy soils support extensive root system',
        rainfall: 'High water requirement met by abundant rainfall',
        temperature: 'Tropical temperatures accelerate growth',
        waterSource: 'Irrigation essential for year-round cultivation',
        region: 'Established sugar industry infrastructure in this region'
      }
    },
    {
      name: 'Bajra',
      icon: '🌿',
      idealSoil: ['sandy', 'loamy'],
      idealRainfall: ['below_500', '500_1000'],
      idealTemperature: ['30_40', 'above_40'],
      idealWaterSource: ['rain_fed'],
      idealRegion: ['west', 'north', 'central'],
      yieldPerAcre: '8-12 quintals',
      priceRange: '₹2,200 - ₹2,600/quintal',
      reasons: {
        soil: 'Drought-resistant crop suited for sandy soils',
        rainfall: 'Thrives in low rainfall arid conditions',
        temperature: 'Heat-tolerant variety for hot climates',
        waterSource: 'Minimal water needs, perfect for rain-fed farming',
        region: 'Traditional millet crop of arid western regions'
      }
    },
    {
      name: 'Jowar',
      icon: '🌾',
      idealSoil: ['black_cotton', 'loamy', 'clay'],
      idealRainfall: ['500_1000'],
      idealTemperature: ['20_30', '30_40'],
      idealWaterSource: ['rain_fed'],
      idealRegion: ['central', 'west', 'south'],
      yieldPerAcre: '10-15 quintals',
      priceRange: '₹2,400 - ₹3,000/quintal',
      reasons: {
        soil: 'Adapts well to heavy black cotton soils',
        rainfall: 'Moderate rainfall supports optimal growth',
        temperature: 'Warm season crop with heat tolerance',
        waterSource: 'Efficient water use in rain-fed conditions',
        region: 'Major sorghum producing region of India'
      }
    },
    {
      name: 'Maize',
      icon: '🌽',
      idealSoil: ['loamy', 'sandy'],
      idealRainfall: ['500_1000', 'above_1000'],
      idealTemperature: ['20_30'],
      idealWaterSource: ['irrigated', 'rain_fed'],
      idealRegion: ['north', 'central', 'east'],
      yieldPerAcre: '25-35 quintals',
      priceRange: '₹1,700 - ₹2,100/quintal',
      reasons: {
        soil: 'Well-drained loamy soil ensures healthy root growth',
        rainfall: 'Adequate rainfall during growing season',
        temperature: 'Moderate temperatures ideal for kernel development',
        waterSource: 'Flexible water management options available',
        region: 'Growing demand for maize in this region'
      }
    },
    {
      name: 'Soybean',
      icon: '🫘',
      idealSoil: ['loamy', 'clay'],
      idealRainfall: ['500_1000', 'above_1000'],
      idealTemperature: ['20_30'],
      idealWaterSource: ['rain_fed', 'irrigated'],
      idealRegion: ['central', 'west'],
      yieldPerAcre: '10-15 quintals',
      priceRange: '₹3,800 - ₹4,500/quintal',
      reasons: {
        soil: 'Nitrogen-fixing crop enriches loamy and clay soils',
        rainfall: 'Monsoon rainfall timing matches crop cycle',
        temperature: 'Moderate temperatures support pod formation',
        waterSource: 'Rain-fed cultivation is highly successful',
        region: 'Major soybean production hub of India'
      }
    },
    {
      name: 'Groundnut',
      icon: '🥜',
      idealSoil: ['sandy', 'loamy'],
      idealRainfall: ['500_1000'],
      idealTemperature: ['20_30', '30_40'],
      idealWaterSource: ['rain_fed'],
      idealRegion: ['west', 'south', 'central'],
      yieldPerAcre: '12-18 quintals',
      priceRange: '₹4,500 - ₹5,500/quintal',
      reasons: {
        soil: 'Sandy soil allows easy pod development underground',
        rainfall: 'Moderate rainfall with dry harvest period ideal',
        temperature: 'Warm temperatures enhance oil content',
        waterSource: 'Well-suited for rain-fed cultivation',
        region: 'Established groundnut processing industry'
      }
    },
    {
      name: 'Turmeric',
      icon: '🌿',
      idealSoil: ['loamy', 'clay'],
      idealRainfall: ['above_1000'],
      idealTemperature: ['20_30', '30_40'],
      idealWaterSource: ['irrigated'],
      idealRegion: ['south', 'east', 'central'],
      yieldPerAcre: '80-100 quintals (fresh)',
      priceRange: '₹6,000 - ₹8,000/quintal (dry)',
      reasons: {
        soil: 'Rich loamy soil supports rhizome development',
        rainfall: 'High rainfall meets high water requirement',
        temperature: 'Tropical climate enhances curcumin content',
        waterSource: 'Regular irrigation ensures quality rhizomes',
        region: 'Traditional turmeric growing belt of India'
      }
    }
  ];
  
  // Form submission handler
  cropForm.addEventListener('submit', function(e) {
    e.preventDefault();
    
    const soilType = document.getElementById('soilType').value;
    const rainfall = document.getElementById('rainfall').value;
    const temperature = document.getElementById('temperature').value;
    const waterSource = document.getElementById('waterSource').value;
    const region = document.getElementById('region').value;
    
    // Validate all fields are selected
    if (!soilType || !rainfall || !temperature || !waterSource || !region) {
      alert('Please fill in all fields to get recommendations');
      return;
    }
    
    // Get recommendations
    const recommendations = getRecommendations(soilType, rainfall, temperature, waterSource, region);
    
    // Display results
    displayResults(recommendations);
  });
  
  function getRecommendations(soilType, rainfall, temperature, waterSource, region) {
    // Score each crop based on matching conditions
    const scoredCrops = crops.map(crop => {
      let score = 0;
      let matchedConditions = [];
      
      // Check soil match (+1 point)
      if (crop.idealSoil.includes(soilType)) {
        score++;
        matchedConditions.push({ type: 'soil', reason: crop.reasons.soil });
      }
      
      // Check rainfall match (+1 point)
      if (crop.idealRainfall.includes(rainfall)) {
        score++;
        matchedConditions.push({ type: 'rainfall', reason: crop.reasons.rainfall });
      }
      
      // Check temperature match (+1 point)
      if (crop.idealTemperature.includes(temperature)) {
        score++;
        matchedConditions.push({ type: 'temperature', reason: crop.reasons.temperature });
      }
      
      // Check water source match (+1 point)
      if (crop.idealWaterSource.includes(waterSource)) {
        score++;
        matchedConditions.push({ type: 'waterSource', reason: crop.reasons.waterSource });
      }
      
      // Check region match (+1 point)
      if (crop.idealRegion.includes(region)) {
        score++;
        matchedConditions.push({ type: 'region', reason: crop.reasons.region });
      }
      
      return {
        ...crop,
        score: score,
        matchedConditions: matchedConditions,
        // Pick the best reason to display
        primaryReason: matchedConditions.length > 0 
          ? matchedConditions[0].reason 
          : 'Suitable for diverse growing conditions'
      };
    });
    
    // Sort by score (descending) and return top 3
    scoredCrops.sort((a, b) => b.score - a.score);
    return scoredCrops.slice(0, 3);
  }
  
  function displayResults(recommendations) {
    // Clear previous results
    cropsGrid.innerHTML = '';
    
    // Create crop cards
    recommendations.forEach((crop, index) => {
      const card = createCropCard(crop, index + 1);
      cropsGrid.appendChild(card);
    });
    
    // Show results section
    resultsSection.classList.add('show');
    
    // Smooth scroll to results
    resultsSection.scrollIntoView({ behavior: 'smooth', block: 'start' });
  }
  
  function createCropCard(crop, rank) {
    const card = document.createElement('div');
    card.className = `crop-card rank-${rank}`;
    
    // Generate stars based on score
    const stars = generateStars(crop.score);
    
    card.innerHTML = `
      <div class="rank-badge">#${rank}</div>
      <div class="crop-header">
        <span class="crop-icon">${crop.icon}</span>
        <h3 class="crop-name">${crop.name}</h3>
      </div>
      <div class="suitability">
        <span class="suitability-label">Suitability Score:</span>
        <div class="score-stars">${stars}</div>
        <span class="score-text">${crop.score}/5</span>
      </div>
      <div class="crop-details">
        <div class="detail-row">
          <span class="detail-label">📊 Expected Yield</span>
          <span class="detail-value">${crop.yieldPerAcre}</span>
        </div>
        <div class="detail-row">
          <span class="detail-label">💰 Market Price</span>
          <span class="detail-value">${crop.priceRange}</span>
        </div>
      </div>
      <div class="reason">
        <div class="reason-label">Why This Crop?</div>
        <div class="reason-text">${crop.primaryReason}</div>
      </div>
    `;
    
    return card;
  }
  
  function generateStars(score) {
    let starsHTML = '';
    for (let i = 1; i <= 5; i++) {
      if (i <= score) {
        starsHTML += '<span class="star filled">★</span>';
      } else {
        starsHTML += '<span class="star empty">☆</span>';
      }
    }
    return starsHTML;
  }
});

// Logout function
function logout() {
  sessionStorage.removeItem('isLoggedIn');
  sessionStorage.removeItem('userEmail');
  window.location.href = 'index.html';
}
