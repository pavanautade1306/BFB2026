// Login Page JavaScript

document.addEventListener('DOMContentLoaded', function() {
  const loginForm = document.getElementById('loginForm');
  const signUpBtn = document.getElementById('signUpBtn');
  const errorMessage = document.getElementById('errorMessage');
  
  // Check if user is already logged in
  if (sessionStorage.getItem('isLoggedIn') === 'true') {
    window.location.href = 'main.html';
  }
  
  // Form submission handler
  loginForm.addEventListener('submit', function(e) {
    e.preventDefault();
    handleAuth('login');
  });
  
  // Sign up button handler
  signUpBtn.addEventListener('click', function() {
    handleAuth('signup');
  });
  
  function handleAuth(type) {
    const emailMobile = document.getElementById('emailMobile').value.trim();
    const password = document.getElementById('password').value;
    const confirmPassword = document.getElementById('confirmPassword').value;
    
    // Clear previous error
    errorMessage.textContent = '';
    
    // Validate email/mobile
    if (!emailMobile) {
      showError('Please enter email or mobile number');
      return;
    }
    
    // Validate email format or mobile number
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    const mobileRegex = /^[0-9]{10}$/;
    
    if (!emailRegex.test(emailMobile) && !mobileRegex.test(emailMobile)) {
      showError('Please enter a valid email or 10-digit mobile number');
      return;
    }
    
    // Validate password
    if (!password) {
      showError('Please enter a password');
      return;
    }
    
    if (password.length < 6) {
      showError('Password must be at least 6 characters');
      return;
    }
    
    // Validate password confirmation
    if (password !== confirmPassword) {
      showError('Passwords do not match');
      return;
    }
    
    // Simulate authentication (in a real app, this would be an API call)
    if (type === 'signup') {
      // Store user credentials (demo only - never do this in production)
      localStorage.setItem('user_' + emailMobile, JSON.stringify({
        email: emailMobile,
        password: password
      }));
      
      showSuccess('Account created successfully! Redirecting...');
      setTimeout(() => {
        sessionStorage.setItem('isLoggedIn', 'true');
        sessionStorage.setItem('userEmail', emailMobile);
        window.location.href = 'main.html';
      }, 1500);
    } else {
      // Check credentials
      const storedUser = localStorage.getItem('user_' + emailMobile);
      
      if (storedUser) {
        const userData = JSON.parse(storedUser);
        if (userData.password === password) {
          showSuccess('Login successful! Redirecting...');
          setTimeout(() => {
            sessionStorage.setItem('isLoggedIn', 'true');
            sessionStorage.setItem('userEmail', emailMobile);
            window.location.href = 'main.html';
          }, 1000);
        } else {
          showError('Invalid password');
        }
      } else {
        // For demo, allow any login
        showSuccess('Welcome! Redirecting...');
        setTimeout(() => {
          sessionStorage.setItem('isLoggedIn', 'true');
          sessionStorage.setItem('userEmail', emailMobile);
          window.location.href = 'main.html';
        }, 1000);
      }
    }
  }
  
  function showError(message) {
    errorMessage.style.color = '#D32F2F';
    errorMessage.textContent = message;
  }
  
  function showSuccess(message) {
    errorMessage.style.color = '#2E7D32';
    errorMessage.textContent = message;
  }
});
